; ModuleID = 'coil'
source_filename = "coil"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%alloc.Allocator = type { ptr, ptr, ptr, ptr }

%alloc.Arena = type { ptr, i64, i64 }

%coil.core.Option__ptr_i8 = type { i32, [1 x i64] }

%coil.core.Result__i64__io.IoError = type { i32, [2 x i64] }

%io.FixBuf = type { ptr, i64, i64 }

%io.IoError = type { i32, [1 x i64] }

%io.Reader = type { ptr, ptr }

%io.Writer = type { ptr, ptr }

@g.0 = global %alloc.Allocator zeroinitializer

@g.1 = global %io.Writer zeroinitializer

@g.2 = global %io.Writer zeroinitializer

@g.3 = global %io.Reader zeroinitializer

@g.4 = global %io.Writer zeroinitializer

@g.5 = global %io.FixBuf zeroinitializer

@str.0 = private constant [8 x i8] c"answer=\00"

@str.1 = private constant [4 x i8] c"inf\00"

@str.2 = private constant [5 x i8] c"true\00"

@str.3 = private constant [6 x i8] c"false\00"

@str.4 = private constant [4 x i8] c"NaN\00"

declare i64 @abort()

declare void @free(ptr)

declare ptr @malloc(i64)

declare ptr @memcpy(ptr, ptr, i64)

declare i64 @read(i32, ptr, i64)

declare ptr @realloc(ptr, i64)

declare i64 @strlen(ptr)

declare i64 @write(i32, ptr, i64)

define internal double @"coil.core.Add$f64$+"(double %a, double %b) {
entry:
  %fadd = fadd double %a, %b
  ret double %fadd
}

define internal i64 @"coil.core.Add$i64$+"(i64 %a, i64 %b) {
entry:
  %add = add i64 %a, %b
  ret i64 %add
}

define internal i64 @"coil.core.BitAnd$i64$&"(i64 %a, i64 %b) {
entry:
  %and = and i64 %a, %b
  ret i64 %and
}

define internal i64 @"coil.core.BitOr$i64$|"(i64 %a, i64 %b) {
entry:
  %or = or i64 %a, %b
  ret i64 %or
}

define internal i64 @"coil.core.BitXor$i64$^"(i64 %a, i64 %b) {
entry:
  %xor = xor i64 %a, %b
  ret i64 %xor
}

define internal double @"coil.core.Div$f64$/"(double %a, double %b) {
entry:
  %fdiv = fdiv double %a, %b
  ret double %fdiv
}

define internal i64 @"coil.core.Div$i64$/"(i64 %a, i64 %b) {
entry:
  %div = sdiv i64 %a, %b
  ret i64 %div
}

define internal i1 @"coil.core.Eq$bool$="(i1 %a, i1 %b) {
entry:
  %ifc = icmp ne i1 %a, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  ret i1 %b

else:                                             ; preds = %entry
  %ifc1 = icmp ne i1 %b, false
  br i1 %ifc1, label %then2, label %else3

then2:                                            ; preds = %else
  ret i1 false

else3:                                            ; preds = %else
  ret i1 true
}

define internal i1 @"coil.core.Eq$i16$="(i16 %a, i16 %b) {
entry:
  %cmp = icmp eq i16 %a, %b
  ret i1 %cmp
}

define internal i1 @"coil.core.Eq$i32$="(i32 %a, i32 %b) {
entry:
  %cmp = icmp eq i32 %a, %b
  ret i1 %cmp
}

define internal i1 @"coil.core.Eq$i64$="(i64 %a, i64 %b) {
entry:
  %cmp = icmp eq i64 %a, %b
  ret i1 %cmp
}

define internal i1 @"coil.core.Eq$i8$="(i8 %a, i8 %b) {
entry:
  %cmp = icmp eq i8 %a, %b
  ret i1 %cmp
}

define internal i1 @"coil.core.Eq$u16$="(i16 %a, i16 %b) {
entry:
  %cmp = icmp eq i16 %a, %b
  ret i1 %cmp
}

define internal i1 @"coil.core.Eq$u32$="(i32 %a, i32 %b) {
entry:
  %cmp = icmp eq i32 %a, %b
  ret i1 %cmp
}

define internal i1 @"coil.core.Eq$u64$="(i64 %a, i64 %b) {
entry:
  %cmp = icmp eq i64 %a, %b
  ret i1 %cmp
}

define internal i1 @"coil.core.Eq$u8$="(i8 %a, i8 %b) {
entry:
  %cmp = icmp eq i8 %a, %b
  ret i1 %cmp
}

define internal i64 @"coil.core.Hash$i64$hash"(i64 %x) {
entry:
  ret i64 %x
}

define internal double @"coil.core.Mul$f64$*"(double %a, double %b) {
entry:
  %fmul = fmul double %a, %b
  ret double %fmul
}

define internal i64 @"coil.core.Mul$i64$*"(i64 %a, i64 %b) {
entry:
  %mul = mul i64 %a, %b
  ret i64 %mul
}

define internal i1 @"coil.core.Ord$f64$<"(double %a, double %b) {
entry:
  %fcmp = fcmp olt double %a, %b
  ret i1 %fcmp
}

define internal i1 @"coil.core.Ord$f64$<="(double %a, double %b) {
entry:
  %fcmp = fcmp ole double %a, %b
  ret i1 %fcmp
}

define internal i1 @"coil.core.Ord$f64$>"(double %a, double %b) {
entry:
  %fcmp = fcmp ogt double %a, %b
  ret i1 %fcmp
}

define internal i1 @"coil.core.Ord$f64$>="(double %a, double %b) {
entry:
  %fcmp = fcmp oge double %a, %b
  ret i1 %fcmp
}

define internal i1 @"coil.core.Ord$i64$<"(i64 %a, i64 %b) {
entry:
  %cmp = icmp slt i64 %a, %b
  ret i1 %cmp
}

define internal i1 @"coil.core.Ord$i64$<="(i64 %a, i64 %b) {
entry:
  %cmp = icmp sle i64 %a, %b
  ret i1 %cmp
}

define internal i1 @"coil.core.Ord$i64$>"(i64 %a, i64 %b) {
entry:
  %cmp = icmp sgt i64 %a, %b
  ret i1 %cmp
}

define internal i1 @"coil.core.Ord$i64$>="(i64 %a, i64 %b) {
entry:
  %cmp = icmp sge i64 %a, %b
  ret i1 %cmp
}

define internal i64 @"coil.core.Rem$i64$%"(i64 %a, i64 %b) {
entry:
  %rem = srem i64 %a, %b
  ret i64 %rem
}

define internal i64 @"coil.core.Shl$i64$<<"(i64 %a, i64 %b) {
entry:
  %shl = shl i64 %a, %b
  ret i64 %shl
}

define internal i64 @"coil.core.Shr$i64$>>"(i64 %a, i64 %b) {
entry:
  %shr = ashr i64 %a, %b
  ret i64 %shr
}

define internal double @"coil.core.Sub$f64$-"(double %a, double %b) {
entry:
  %fsub = fsub double %a, %b
  ret double %fsub
}

define internal i64 @"coil.core.Sub$i64$-"(i64 %a, i64 %b) {
entry:
  %sub = sub i64 %a, %b
  ret i64 %sub
}

define internal ptr @__coil_llvm_ir_0({ ptr, i64 } %0) #0 {
  %d = extractvalue { ptr, i64 } %0, 0
  ret ptr %d
}

define internal i64 @__coil_llvm_ir_1({ ptr, i64 } %0) #0 {
  %l = extractvalue { ptr, i64 } %0, 1
  ret i64 %l
}

define internal i64 @alloc.align-up(i64 %x, i64 %a) {
entry:
  %sub = sub i64 %a, 1
  %add = add i64 %x, %sub
  %div = sdiv i64 %add, %a
  %mul = mul i64 %div, %a
  ret i64 %mul
}

define internal %coil.core.Option__ptr_i8 @alloc.alloc-slice__i8(ptr %a, i64 %n) {
entry:
  %sum.tmp5 = alloca %coil.core.Option__ptr_i8, align 8
  %sum.tmp = alloca %coil.core.Option__ptr_i8, align 8
  %match.tmp = alloca %coil.core.Option__ptr_i8, align 8
  %mul = mul i64 %n, 1
  %call = call %coil.core.Option__ptr_i8 @alloc.raw-alloc(ptr %a, i64 %mul, i64 1)
  store %coil.core.Option__ptr_i8 %call, ptr %match.tmp, align 8
  %tag = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %match.tmp, i32 0, i32 0
  %tag1 = load i32, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %match.tmp, i32 0, i32 1
  switch i32 %tag1, label %match.default [
    i32 0, label %arm
    i32 1, label %arm2
  ]

arm:                                              ; preds = %entry
  %tag3 = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp, i32 0, i32 0
  store i32 0, ptr %tag3, align 4
  %payload4 = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp, i32 0, i32 1
  %sum = load %coil.core.Option__ptr_i8, ptr %sum.tmp, align 8
  ret %coil.core.Option__ptr_i8 %sum

arm2:                                             ; preds = %entry
  %vf = getelementptr inbounds nuw { ptr }, ptr %payload, i32 0, i32 0
  %p = load ptr, ptr %vf, align 8
  %tag6 = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp5, i32 0, i32 0
  store i32 1, ptr %tag6, align 4
  %payload7 = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp5, i32 0, i32 1
  %vf8 = getelementptr inbounds nuw { ptr }, ptr %payload7, i32 0, i32 0
  store ptr %p, ptr %vf8, align 8
  %sum9 = load %coil.core.Option__ptr_i8, ptr %sum.tmp5, align 8
  ret %coil.core.Option__ptr_i8 %sum9

match.default:                                    ; preds = %entry
  unreachable
}

define internal %coil.core.Option__ptr_i8 @alloc.ar-alloc(ptr %ctx, i64 %size, i64 %align) {
entry:
  %sum.tmp5 = alloca %coil.core.Option__ptr_i8, align 8
  %sum.tmp = alloca %coil.core.Option__ptr_i8, align 8
  %field = getelementptr inbounds nuw %alloc.Arena, ptr %ctx, i32 0, i32 1
  %load = load i64, ptr %field, align 8
  %call = call i64 @alloc.align-up(i64 %load, i64 %align)
  %add = add i64 %call, %size
  %field1 = getelementptr inbounds nuw %alloc.Arena, ptr %ctx, i32 0, i32 2
  %load2 = load i64, ptr %field1, align 8
  %cmp = icmp sgt i64 %add, %load2
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %tag = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp, i32 0, i32 0
  store i32 0, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp, i32 0, i32 1
  %sum = load %coil.core.Option__ptr_i8, ptr %sum.tmp, align 8
  ret %coil.core.Option__ptr_i8 %sum

else:                                             ; preds = %entry
  %field3 = getelementptr inbounds nuw %alloc.Arena, ptr %ctx, i32 0, i32 1
  %add4 = add i64 %call, %size
  store i64 %add4, ptr %field3, align 8
  %tag6 = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp5, i32 0, i32 0
  store i32 1, ptr %tag6, align 4
  %payload7 = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp5, i32 0, i32 1
  %field8 = getelementptr inbounds nuw %alloc.Arena, ptr %ctx, i32 0, i32 0
  %load9 = load ptr, ptr %field8, align 8
  %idx = getelementptr i8, ptr %load9, i64 %call
  %vf = getelementptr inbounds nuw { ptr }, ptr %payload7, i32 0, i32 0
  store ptr %idx, ptr %vf, align 8
  %sum10 = load %coil.core.Option__ptr_i8, ptr %sum.tmp5, align 8
  ret %coil.core.Option__ptr_i8 %sum10
}

define internal i64 @alloc.ar-free(ptr %ctx, ptr %p, i64 %size, i64 %align) {
entry:
  ret i64 0
}

define internal %coil.core.Option__ptr_i8 @alloc.ar-resize(ptr %ctx, ptr %p, i64 %old, i64 %new, i64 %align) {
entry:
  %sum.tmp = alloca %coil.core.Option__ptr_i8, align 8
  %tag = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp, i32 0, i32 0
  store i32 0, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp, i32 0, i32 1
  %sum = load %coil.core.Option__ptr_i8, ptr %sum.tmp, align 8
  ret %coil.core.Option__ptr_i8 %sum
}

define internal ptr @alloc.arena-allocator(i64 %cap) {
entry:
  %call = call ptr @malloc(i64 24)
  %call1 = call ptr @malloc(i64 32)
  %call2 = call ptr @malloc(i64 %cap)
  %call3 = call ptr @alloc.arena-over-buffer(ptr %call, ptr %call1, ptr %call2, i64 %cap)
  ret ptr %call3
}

define internal ptr @alloc.arena-over-buffer(ptr %ar, ptr %a, ptr %buf, i64 %cap) {
entry:
  %field = getelementptr inbounds nuw %alloc.Arena, ptr %ar, i32 0, i32 0
  store ptr %buf, ptr %field, align 8
  %field1 = getelementptr inbounds nuw %alloc.Arena, ptr %ar, i32 0, i32 1
  store i64 0, ptr %field1, align 8
  %field2 = getelementptr inbounds nuw %alloc.Arena, ptr %ar, i32 0, i32 2
  store i64 %cap, ptr %field2, align 8
  %field3 = getelementptr inbounds nuw %alloc.Allocator, ptr %a, i32 0, i32 0
  store ptr @alloc.ar-alloc, ptr %field3, align 8
  %field4 = getelementptr inbounds nuw %alloc.Allocator, ptr %a, i32 0, i32 1
  store ptr @alloc.ar-resize, ptr %field4, align 8
  %field5 = getelementptr inbounds nuw %alloc.Allocator, ptr %a, i32 0, i32 2
  store ptr @alloc.ar-free, ptr %field5, align 8
  %field6 = getelementptr inbounds nuw %alloc.Allocator, ptr %a, i32 0, i32 3
  store ptr %ar, ptr %field6, align 8
  ret ptr %a
}

define internal %coil.core.Option__ptr_i8 @alloc.ma-alloc(ptr %ctx, i64 %size, i64 %align) {
entry:
  %sum.tmp1 = alloca %coil.core.Option__ptr_i8, align 8
  %sum.tmp = alloca %coil.core.Option__ptr_i8, align 8
  %call = call ptr @malloc(i64 %size)
  %ptrtoint = ptrtoint ptr %call to i64
  %cmp = icmp eq i64 %ptrtoint, 0
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %tag = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp, i32 0, i32 0
  store i32 0, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp, i32 0, i32 1
  %sum = load %coil.core.Option__ptr_i8, ptr %sum.tmp, align 8
  ret %coil.core.Option__ptr_i8 %sum

else:                                             ; preds = %entry
  %tag2 = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp1, i32 0, i32 0
  store i32 1, ptr %tag2, align 4
  %payload3 = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp1, i32 0, i32 1
  %vf = getelementptr inbounds nuw { ptr }, ptr %payload3, i32 0, i32 0
  store ptr %call, ptr %vf, align 8
  %sum4 = load %coil.core.Option__ptr_i8, ptr %sum.tmp1, align 8
  ret %coil.core.Option__ptr_i8 %sum4
}

define internal i64 @alloc.ma-free(ptr %ctx, ptr %p, i64 %size, i64 %align) {
entry:
  tail call void @free(ptr %p)
  ret i64 0
}

define internal %coil.core.Option__ptr_i8 @alloc.ma-resize(ptr %ctx, ptr %p, i64 %old, i64 %new, i64 %align) {
entry:
  %sum.tmp1 = alloca %coil.core.Option__ptr_i8, align 8
  %sum.tmp = alloca %coil.core.Option__ptr_i8, align 8
  %call = call ptr @realloc(ptr %p, i64 %new)
  %ptrtoint = ptrtoint ptr %call to i64
  %cmp = icmp eq i64 %ptrtoint, 0
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %tag = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp, i32 0, i32 0
  store i32 0, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp, i32 0, i32 1
  %sum = load %coil.core.Option__ptr_i8, ptr %sum.tmp, align 8
  ret %coil.core.Option__ptr_i8 %sum

else:                                             ; preds = %entry
  %tag2 = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp1, i32 0, i32 0
  store i32 1, ptr %tag2, align 4
  %payload3 = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %sum.tmp1, i32 0, i32 1
  %vf = getelementptr inbounds nuw { ptr }, ptr %payload3, i32 0, i32 0
  store ptr %call, ptr %vf, align 8
  %sum4 = load %coil.core.Option__ptr_i8, ptr %sum.tmp1, align 8
  ret %coil.core.Option__ptr_i8 %sum4
}

define internal ptr @alloc.malloc-allocator() {
entry:
  store ptr @alloc.ma-alloc, ptr @g.0, align 8
  store ptr @alloc.ma-resize, ptr getelementptr inbounds nuw (%alloc.Allocator, ptr @g.0, i32 0, i32 1), align 8
  store ptr @alloc.ma-free, ptr getelementptr inbounds nuw (%alloc.Allocator, ptr @g.0, i32 0, i32 2), align 8
  store ptr @g.0, ptr getelementptr inbounds nuw (%alloc.Allocator, ptr @g.0, i32 0, i32 3), align 8
  ret ptr @g.0
}

define internal i64 @alloc.oom() {
entry:
  %call = call i64 @abort()
  ret i64 0
}

define internal %coil.core.Option__ptr_i8 @alloc.raw-alloc(ptr %a, i64 %size, i64 %align) {
entry:
  %field = getelementptr inbounds nuw %alloc.Allocator, ptr %a, i32 0, i32 0
  %load = load ptr, ptr %field, align 8
  %field1 = getelementptr inbounds nuw %alloc.Allocator, ptr %a, i32 0, i32 3
  %load2 = load ptr, ptr %field1, align 8
  %callptr = call %coil.core.Option__ptr_i8 %load(ptr %load2, i64 %size, i64 %align)
  ret %coil.core.Option__ptr_i8 %callptr
}

define internal i64 @alloc.raw-free(ptr %a, ptr %p, i64 %size, i64 %align) {
entry:
  %field = getelementptr inbounds nuw %alloc.Allocator, ptr %a, i32 0, i32 2
  %load = load ptr, ptr %field, align 8
  %field1 = getelementptr inbounds nuw %alloc.Allocator, ptr %a, i32 0, i32 3
  %load2 = load ptr, ptr %field1, align 8
  %callptr = call i64 %load(ptr %load2, ptr %p, i64 %size, i64 %align)
  ret i64 %callptr
}

define internal %coil.core.Option__ptr_i8 @alloc.raw-resize(ptr %a, ptr %p, i64 %old, i64 %new, i64 %align) {
entry:
  %field = getelementptr inbounds nuw %alloc.Allocator, ptr %a, i32 0, i32 1
  %load = load ptr, ptr %field, align 8
  %field1 = getelementptr inbounds nuw %alloc.Allocator, ptr %a, i32 0, i32 3
  %load2 = load ptr, ptr %field1, align 8
  %callptr = call %coil.core.Option__ptr_i8 %load(ptr %load2, ptr %p, i64 %old, i64 %new, i64 %align)
  ret %coil.core.Option__ptr_i8 %callptr
}

define internal ptr @alloc.unwrap-ptr__i8(ptr %o) {
entry:
  %match.tmp = alloca %coil.core.Option__ptr_i8, align 8
  %load = load %coil.core.Option__ptr_i8, ptr %o, align 8
  store %coil.core.Option__ptr_i8 %load, ptr %match.tmp, align 8
  %tag = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %match.tmp, i32 0, i32 0
  %tag1 = load i32, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Option__ptr_i8, ptr %match.tmp, i32 0, i32 1
  switch i32 %tag1, label %match.default [
    i32 0, label %arm
    i32 1, label %arm2
  ]

arm:                                              ; preds = %entry
  ret ptr null

arm2:                                             ; preds = %entry
  %vf = getelementptr inbounds nuw { ptr }, ptr %payload, i32 0, i32 0
  %p = load ptr, ptr %vf, align 8
  ret ptr %p

match.default:                                    ; preds = %entry
  unreachable
}

define internal %coil.core.Result__i64__io.IoError @app.greet(ptr %w, i64 %n) {
entry:
  %call = call %coil.core.Result__i64__io.IoError @io.print-str(ptr %w, { ptr, i64 } { ptr @str.0, i64 7 })
  %call1 = call %coil.core.Result__i64__io.IoError @io.print-int(ptr %w, i64 %n)
  %call2 = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 10)
  ret %coil.core.Result__i64__io.IoError %call2
}

define internal %coil.core.Result__i64__io.IoError @fmt.f--abs(ptr %w, double %x) {
entry:
  %fcmp = fcmp ogt double %x, 0.000000e+00
  %ifc = icmp ne i1 %fcmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %fdiv = fdiv double 1.000000e+00, %x
  %fcmp1 = fcmp oeq double %fdiv, 0.000000e+00
  br label %ifcont

else:                                             ; preds = %entry
  br label %ifcont

ifcont:                                           ; preds = %else, %then
  %ifval = phi i1 [ %fcmp1, %then ], [ false, %else ]
  %ifc2 = icmp ne i1 %ifval, false
  br i1 %ifc2, label %then3, label %else4

then3:                                            ; preds = %ifcont
  %call = call %coil.core.Result__i64__io.IoError @io.print-str(ptr %w, { ptr, i64 } { ptr @str.1, i64 3 })
  ret %coil.core.Result__i64__io.IoError %call

else4:                                            ; preds = %ifcont
  %fcmp5 = fcmp olt double %x, 0x43E0000000000000
  %ifc6 = icmp ne i1 %fcmp5, false
  br i1 %ifc6, label %then7, label %else8

then7:                                            ; preds = %else4
  %call9 = call %coil.core.Result__i64__io.IoError @fmt.f--fixed(ptr %w, double %x)
  ret %coil.core.Result__i64__io.IoError %call9

else8:                                            ; preds = %else4
  %call10 = call %coil.core.Result__i64__io.IoError @fmt.f--sci(ptr %w, double %x)
  ret %coil.core.Result__i64__io.IoError %call10
}

define internal %coil.core.Result__i64__io.IoError @fmt.f--fixed(ptr %w, double %x) {
entry:
  %fptosi = fptosi double %x to i64
  %sitofp = sitofp i64 %fptosi to double
  %fsub = fsub double %x, %sitofp
  %fmul = fmul double %fsub, 1.000000e+06
  %fadd = fadd double %fmul, 5.000000e-01
  %fptosi1 = fptosi double %fadd to i64
  %cmp = icmp eq i64 %fptosi1, 1000000
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %add = add i64 %fptosi, 1
  br label %ifcont

else:                                             ; preds = %entry
  br label %ifcont

ifcont:                                           ; preds = %else, %then
  %ifval = phi i64 [ %add, %then ], [ %fptosi, %else ]
  %ifc2 = icmp ne i1 %cmp, false
  br i1 %ifc2, label %then3, label %else4

then3:                                            ; preds = %ifcont
  br label %ifcont5

else4:                                            ; preds = %ifcont
  br label %ifcont5

ifcont5:                                          ; preds = %else4, %then3
  %ifval6 = phi i64 [ 0, %then3 ], [ %fptosi1, %else4 ]
  %call = call %coil.core.Result__i64__io.IoError @io.print-int(ptr %w, i64 %ifval)
  %call7 = call %coil.core.Result__i64__io.IoError @fmt.f--frac(ptr %w, i64 %ifval6)
  ret %coil.core.Result__i64__io.IoError %call7
}

define internal %coil.core.Result__i64__io.IoError @fmt.f--frac(ptr %w, i64 %fr6) {
entry:
  %stack.slot = alloca i64, align 8
  store i64 %fr6, ptr %stack.slot, align 8
  %stack.slot1 = alloca i64, align 8
  store i64 6, ptr %stack.slot1, align 8
  br label %loop.body

loop.body:                                        ; preds = %then5, %entry
  %load = load i64, ptr %stack.slot1, align 8
  %cmp = icmp sgt i64 %load, 1
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

loop.after:                                       ; preds = %else6
  %loop.val = phi i64 [ 0, %else6 ]
  %call = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 46)
  %load9 = load i64, ptr %stack.slot1, align 8
  %load10 = load i64, ptr %stack.slot, align 8
  %call11 = call i64 @fmt.f--ndigits(i64 %load10)
  %sub12 = sub i64 %load9, %call11
  %call13 = call %coil.core.Result__i64__io.IoError @fmt.f--zeros(ptr %w, i64 %sub12)
  %load14 = load i64, ptr %stack.slot, align 8
  %call15 = call %coil.core.Result__i64__io.IoError @io.print-int(ptr %w, i64 %load14)
  ret %coil.core.Result__i64__io.IoError %call15

then:                                             ; preds = %loop.body
  %load2 = load i64, ptr %stack.slot, align 8
  %rem = srem i64 %load2, 10
  %cmp3 = icmp eq i64 %rem, 0
  br label %ifcont

else:                                             ; preds = %loop.body
  br label %ifcont

ifcont:                                           ; preds = %else, %then
  %ifval = phi i1 [ %cmp3, %then ], [ false, %else ]
  %ifc4 = icmp ne i1 %ifval, false
  br i1 %ifc4, label %then5, label %else6

then5:                                            ; preds = %ifcont
  %load7 = load i64, ptr %stack.slot, align 8
  %div = sdiv i64 %load7, 10
  store i64 %div, ptr %stack.slot, align 8
  %load8 = load i64, ptr %stack.slot1, align 8
  %sub = sub i64 %load8, 1
  store i64 %sub, ptr %stack.slot1, align 8
  br label %loop.body

else6:                                            ; preds = %ifcont
  br label %loop.after
}

define internal i64 @fmt.f--ndigits(i64 %n) {
entry:
  %cmp = icmp slt i64 %n, 10
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  ret i64 1

else:                                             ; preds = %entry
  %div = sdiv i64 %n, 10
  %call = call i64 @fmt.f--ndigits(i64 %div)
  %add = add i64 1, %call
  ret i64 %add
}

define internal %coil.core.Result__i64__io.IoError @fmt.f--sci(ptr %w, double %x) {
entry:
  %stack.slot = alloca double, align 8
  store double %x, ptr %stack.slot, align 8
  %stack.slot1 = alloca i64, align 8
  store i64 0, ptr %stack.slot1, align 8
  br label %loop.body

loop.body:                                        ; preds = %then, %entry
  %load = load double, ptr %stack.slot, align 8
  %fcmp = fcmp oge double %load, 1.000000e+01
  %ifc = icmp ne i1 %fcmp, false
  br i1 %ifc, label %then, label %else

loop.after:                                       ; preds = %else
  %loop.val = phi i64 [ 0, %else ]
  %load4 = load double, ptr %stack.slot, align 8
  %call = call %coil.core.Result__i64__io.IoError @fmt.f--fixed(ptr %w, double %load4)
  %call5 = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 101)
  %call6 = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 43)
  %load7 = load i64, ptr %stack.slot1, align 8
  %call8 = call %coil.core.Result__i64__io.IoError @io.print-int(ptr %w, i64 %load7)
  ret %coil.core.Result__i64__io.IoError %call8

then:                                             ; preds = %loop.body
  %load2 = load double, ptr %stack.slot, align 8
  %fdiv = fdiv double %load2, 1.000000e+01
  store double %fdiv, ptr %stack.slot, align 8
  %load3 = load i64, ptr %stack.slot1, align 8
  %add = add i64 %load3, 1
  store i64 %add, ptr %stack.slot1, align 8
  br label %loop.body

else:                                             ; preds = %loop.body
  br label %loop.after
}

define internal %coil.core.Result__i64__io.IoError @fmt.f--zeros(ptr %w, i64 %n) {
entry:
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %cmp = icmp sle i64 %n, 0
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 0, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %vf = getelementptr inbounds nuw { i64 }, ptr %payload, i32 0, i32 0
  store i64 0, ptr %vf, align 8
  %sum = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  ret %coil.core.Result__i64__io.IoError %sum

else:                                             ; preds = %entry
  %call = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 48)
  %sub = sub i64 %n, 1
  %tailcall = tail call %coil.core.Result__i64__io.IoError @fmt.f--zeros(ptr %w, i64 %sub)
  ret %coil.core.Result__i64__io.IoError %tailcall
}

define internal %coil.core.Result__i64__io.IoError @fmt.print-bool(ptr %w, i1 %b) {
entry:
  %ifc = icmp ne i1 %b, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  br label %ifcont

else:                                             ; preds = %entry
  br label %ifcont

ifcont:                                           ; preds = %else, %then
  %ifval = phi { ptr, i64 } [ { ptr @str.2, i64 4 }, %then ], [ { ptr @str.3, i64 5 }, %else ]
  %call = call %coil.core.Result__i64__io.IoError @io.print-str(ptr %w, { ptr, i64 } %ifval)
  ret %coil.core.Result__i64__io.IoError %call
}

define internal %coil.core.Result__i64__io.IoError @fmt.print-char(ptr %w, i64 %c) {
entry:
  %trunc = trunc i64 %c to i8
  %call = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 %trunc)
  ret %coil.core.Result__i64__io.IoError %call
}

define internal %coil.core.Result__i64__io.IoError @fmt.print-f(ptr %w, double %x) {
entry:
  %fcmp = fcmp oeq double %x, %x
  %ifc = icmp ne i1 %fcmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  br label %ifcont

else:                                             ; preds = %entry
  br label %ifcont

ifcont:                                           ; preds = %else, %then
  %ifval = phi i1 [ false, %then ], [ true, %else ]
  %ifc1 = icmp ne i1 %ifval, false
  br i1 %ifc1, label %then2, label %else3

then2:                                            ; preds = %ifcont
  %call = call %coil.core.Result__i64__io.IoError @io.print-str(ptr %w, { ptr, i64 } { ptr @str.4, i64 3 })
  ret %coil.core.Result__i64__io.IoError %call

else3:                                            ; preds = %ifcont
  %fcmp4 = fcmp olt double %x, 0.000000e+00
  %ifc5 = icmp ne i1 %fcmp4, false
  br i1 %ifc5, label %then6, label %else7

then6:                                            ; preds = %else3
  %call8 = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 45)
  %fsub = fsub double 0.000000e+00, %x
  %call9 = call %coil.core.Result__i64__io.IoError @fmt.f--abs(ptr %w, double %fsub)
  ret %coil.core.Result__i64__io.IoError %call9

else7:                                            ; preds = %else3
  %call10 = call %coil.core.Result__i64__io.IoError @fmt.f--abs(ptr %w, double %x)
  ret %coil.core.Result__i64__io.IoError %call10
}

define internal %coil.core.Result__i64__io.IoError @fmt.print-hex(ptr %w, i64 %n) {
entry:
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %match.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %cmp = icmp slt i64 %n, 16
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %cmp1 = icmp slt i64 %n, 10
  %ifc2 = icmp ne i1 %cmp1, false
  br i1 %ifc2, label %then3, label %else4

else:                                             ; preds = %entry
  %div = sdiv i64 %n, 16
  %call6 = call %coil.core.Result__i64__io.IoError @fmt.print-hex(ptr %w, i64 %div)
  store %coil.core.Result__i64__io.IoError %call6, ptr %match.tmp, align 8
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 0
  %tag7 = load i32, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 1
  switch i32 %tag7, label %match.default [
    i32 1, label %arm
    i32 0, label %arm8
  ]

then3:                                            ; preds = %then
  %add = add i64 %n, 48
  br label %ifcont

else4:                                            ; preds = %then
  %add5 = add i64 %n, 87
  br label %ifcont

ifcont:                                           ; preds = %else4, %then3
  %ifval = phi i64 [ %add, %then3 ], [ %add5, %else4 ]
  %trunc = trunc i64 %ifval to i8
  %call = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 %trunc)
  ret %coil.core.Result__i64__io.IoError %call

arm:                                              ; preds = %else
  %vf = getelementptr inbounds nuw { %io.IoError }, ptr %payload, i32 0, i32 0
  %e = load %io.IoError, ptr %vf, align 8
  %tag9 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 1, ptr %tag9, align 4
  %payload10 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %vf11 = getelementptr inbounds nuw { %io.IoError }, ptr %payload10, i32 0, i32 0
  store %io.IoError %e, ptr %vf11, align 8
  %sum = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  ret %coil.core.Result__i64__io.IoError %sum

arm8:                                             ; preds = %else
  %vf12 = getelementptr inbounds nuw { i64 }, ptr %payload, i32 0, i32 0
  %_ = load i64, ptr %vf12, align 8
  %rem = srem i64 %n, 16
  %cmp13 = icmp slt i64 %rem, 10
  %ifc14 = icmp ne i1 %cmp13, false
  br i1 %ifc14, label %then15, label %else16

match.default:                                    ; preds = %else
  unreachable

then15:                                           ; preds = %arm8
  %add17 = add i64 %rem, 48
  br label %ifcont19

else16:                                           ; preds = %arm8
  %add18 = add i64 %rem, 87
  br label %ifcont19

ifcont19:                                         ; preds = %else16, %then15
  %ifval20 = phi i64 [ %add17, %then15 ], [ %add18, %else16 ]
  %trunc21 = trunc i64 %ifval20 to i8
  %call22 = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 %trunc21)
  ret %coil.core.Result__i64__io.IoError %call22
}

define internal %coil.core.Result__i64__io.IoError @fmt.print-i(ptr %w, i64 %n) {
entry:
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %match.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %cmp = icmp slt i64 %n, 0
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %call = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 45)
  store %coil.core.Result__i64__io.IoError %call, ptr %match.tmp, align 8
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 0
  %tag1 = load i32, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 1
  switch i32 %tag1, label %match.default [
    i32 1, label %arm
    i32 0, label %arm2
  ]

else:                                             ; preds = %entry
  %call8 = call %coil.core.Result__i64__io.IoError @io.print-int(ptr %w, i64 %n)
  ret %coil.core.Result__i64__io.IoError %call8

arm:                                              ; preds = %then
  %vf = getelementptr inbounds nuw { %io.IoError }, ptr %payload, i32 0, i32 0
  %e = load %io.IoError, ptr %vf, align 8
  %tag3 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 1, ptr %tag3, align 4
  %payload4 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %vf5 = getelementptr inbounds nuw { %io.IoError }, ptr %payload4, i32 0, i32 0
  store %io.IoError %e, ptr %vf5, align 8
  %sum = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  ret %coil.core.Result__i64__io.IoError %sum

arm2:                                             ; preds = %then
  %vf6 = getelementptr inbounds nuw { i64 }, ptr %payload, i32 0, i32 0
  %_ = load i64, ptr %vf6, align 8
  %sub = sub i64 0, %n
  %call7 = call %coil.core.Result__i64__io.IoError @io.print-int(ptr %w, i64 %sub)
  ret %coil.core.Result__i64__io.IoError %call7

match.default:                                    ; preds = %then
  unreachable
}

define internal %coil.core.Result__i64__io.IoError @fmt.print-line(ptr %w, { ptr, i64 } %s) {
entry:
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %match.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %call = call %coil.core.Result__i64__io.IoError @io.print-str(ptr %w, { ptr, i64 } %s)
  store %coil.core.Result__i64__io.IoError %call, ptr %match.tmp, align 8
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 0
  %tag1 = load i32, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 1
  switch i32 %tag1, label %match.default [
    i32 1, label %arm
    i32 0, label %arm2
  ]

arm:                                              ; preds = %entry
  %vf = getelementptr inbounds nuw { %io.IoError }, ptr %payload, i32 0, i32 0
  %e = load %io.IoError, ptr %vf, align 8
  %tag3 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 1, ptr %tag3, align 4
  %payload4 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %vf5 = getelementptr inbounds nuw { %io.IoError }, ptr %payload4, i32 0, i32 0
  store %io.IoError %e, ptr %vf5, align 8
  %sum = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  ret %coil.core.Result__i64__io.IoError %sum

arm2:                                             ; preds = %entry
  %vf6 = getelementptr inbounds nuw { i64 }, ptr %payload, i32 0, i32 0
  %_ = load i64, ptr %vf6, align 8
  %call7 = call %coil.core.Result__i64__io.IoError @fmt.print-nl(ptr %w)
  ret %coil.core.Result__i64__io.IoError %call7

match.default:                                    ; preds = %entry
  unreachable
}

define internal %coil.core.Result__i64__io.IoError @fmt.print-nl(ptr %w) {
entry:
  %call = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 10)
  ret %coil.core.Result__i64__io.IoError %call
}

define internal %coil.core.Result__i64__io.IoError @fmt.print-u(ptr %w, i64 %n) {
entry:
  %cmp = icmp eq i64 %n, 0
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %call = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 48)
  ret %coil.core.Result__i64__io.IoError %call

else:                                             ; preds = %entry
  %call1 = call %coil.core.Result__i64__io.IoError @fmt.udec-digits(ptr %w, i64 %n)
  ret %coil.core.Result__i64__io.IoError %call1
}

define internal %coil.core.Result__i64__io.IoError @fmt.print-uhex(ptr %w, i64 %n) {
entry:
  %cmp = icmp eq i64 %n, 0
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %call = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 48)
  ret %coil.core.Result__i64__io.IoError %call

else:                                             ; preds = %entry
  %call1 = call %coil.core.Result__i64__io.IoError @fmt.uhex-digits(ptr %w, i64 %n)
  ret %coil.core.Result__i64__io.IoError %call1
}

define internal %coil.core.Result__i64__io.IoError @fmt.udec-digits(ptr %w, i64 %n) {
entry:
  %sum.tmp6 = alloca %coil.core.Result__i64__io.IoError, align 8
  %match.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %cmp = icmp eq i64 %n, 0
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 0, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %vf = getelementptr inbounds nuw { i64 }, ptr %payload, i32 0, i32 0
  store i64 0, ptr %vf, align 8
  %sum = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  ret %coil.core.Result__i64__io.IoError %sum

else:                                             ; preds = %entry
  %udiv = udiv i64 %n, 10
  %call = call %coil.core.Result__i64__io.IoError @fmt.udec-digits(ptr %w, i64 %udiv)
  store %coil.core.Result__i64__io.IoError %call, ptr %match.tmp, align 8
  %tag1 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 0
  %tag2 = load i32, ptr %tag1, align 4
  %payload3 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 1
  switch i32 %tag2, label %match.default [
    i32 1, label %arm
    i32 0, label %arm4
  ]

arm:                                              ; preds = %else
  %vf5 = getelementptr inbounds nuw { %io.IoError }, ptr %payload3, i32 0, i32 0
  %e = load %io.IoError, ptr %vf5, align 8
  %tag7 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, i32 0, i32 0
  store i32 1, ptr %tag7, align 4
  %payload8 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, i32 0, i32 1
  %vf9 = getelementptr inbounds nuw { %io.IoError }, ptr %payload8, i32 0, i32 0
  store %io.IoError %e, ptr %vf9, align 8
  %sum10 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, align 8
  ret %coil.core.Result__i64__io.IoError %sum10

arm4:                                             ; preds = %else
  %vf11 = getelementptr inbounds nuw { i64 }, ptr %payload3, i32 0, i32 0
  %_ = load i64, ptr %vf11, align 8
  %urem = urem i64 %n, 10
  %add = add i64 %urem, 48
  %trunc = trunc i64 %add to i8
  %call12 = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 %trunc)
  ret %coil.core.Result__i64__io.IoError %call12

match.default:                                    ; preds = %else
  unreachable
}

define internal %coil.core.Result__i64__io.IoError @fmt.uhex-digits(ptr %w, i64 %n) {
entry:
  %sum.tmp6 = alloca %coil.core.Result__i64__io.IoError, align 8
  %match.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %cmp = icmp eq i64 %n, 0
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 0, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %vf = getelementptr inbounds nuw { i64 }, ptr %payload, i32 0, i32 0
  store i64 0, ptr %vf, align 8
  %sum = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  ret %coil.core.Result__i64__io.IoError %sum

else:                                             ; preds = %entry
  %udiv = udiv i64 %n, 16
  %call = call %coil.core.Result__i64__io.IoError @fmt.uhex-digits(ptr %w, i64 %udiv)
  store %coil.core.Result__i64__io.IoError %call, ptr %match.tmp, align 8
  %tag1 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 0
  %tag2 = load i32, ptr %tag1, align 4
  %payload3 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 1
  switch i32 %tag2, label %match.default [
    i32 1, label %arm
    i32 0, label %arm4
  ]

arm:                                              ; preds = %else
  %vf5 = getelementptr inbounds nuw { %io.IoError }, ptr %payload3, i32 0, i32 0
  %e = load %io.IoError, ptr %vf5, align 8
  %tag7 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, i32 0, i32 0
  store i32 1, ptr %tag7, align 4
  %payload8 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, i32 0, i32 1
  %vf9 = getelementptr inbounds nuw { %io.IoError }, ptr %payload8, i32 0, i32 0
  store %io.IoError %e, ptr %vf9, align 8
  %sum10 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, align 8
  ret %coil.core.Result__i64__io.IoError %sum10

arm4:                                             ; preds = %else
  %vf11 = getelementptr inbounds nuw { i64 }, ptr %payload3, i32 0, i32 0
  %_ = load i64, ptr %vf11, align 8
  %urem = urem i64 %n, 16
  %cmp12 = icmp slt i64 %urem, 10
  %ifc13 = icmp ne i1 %cmp12, false
  br i1 %ifc13, label %then14, label %else15

match.default:                                    ; preds = %else
  unreachable

then14:                                           ; preds = %arm4
  %add = add i64 %urem, 48
  br label %ifcont

else15:                                           ; preds = %arm4
  %add16 = add i64 %urem, 87
  br label %ifcont

ifcont:                                           ; preds = %else15, %then14
  %ifval = phi i64 [ %add, %then14 ], [ %add16, %else15 ]
  %trunc = trunc i64 %ifval to i8
  %call17 = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 %trunc)
  ret %coil.core.Result__i64__io.IoError %call17
}

define internal %coil.core.Result__i64__io.IoError @io.fb-write(ptr %ctx, ptr %buf, i64 %len) {
entry:
  %sum.tmp15 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp10 = alloca %io.IoError, align 8
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %field = getelementptr inbounds nuw %io.FixBuf, ptr %ctx, i32 0, i32 1
  %load = load i64, ptr %field, align 8
  %field1 = getelementptr inbounds nuw %io.FixBuf, ptr %ctx, i32 0, i32 2
  %load2 = load i64, ptr %field1, align 8
  %sub = sub i64 %load2, %load
  %cmp = icmp slt i64 %len, %sub
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  br label %ifcont

else:                                             ; preds = %entry
  br label %ifcont

ifcont:                                           ; preds = %else, %then
  %ifval = phi i64 [ %len, %then ], [ %sub, %else ]
  %field3 = getelementptr inbounds nuw %io.FixBuf, ptr %ctx, i32 0, i32 0
  %load4 = load ptr, ptr %field3, align 8
  %idx = getelementptr i8, ptr %load4, i64 %load
  %call = call ptr @memcpy(ptr %idx, ptr %buf, i64 %ifval)
  %field5 = getelementptr inbounds nuw %io.FixBuf, ptr %ctx, i32 0, i32 1
  %add = add i64 %load, %ifval
  store i64 %add, ptr %field5, align 8
  %cmp6 = icmp slt i64 %ifval, %len
  %ifc7 = icmp ne i1 %cmp6, false
  br i1 %ifc7, label %then8, label %else9

then8:                                            ; preds = %ifcont
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 1, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %tag11 = getelementptr inbounds nuw %io.IoError, ptr %sum.tmp10, i32 0, i32 0
  store i32 1, ptr %tag11, align 4
  %payload12 = getelementptr inbounds nuw %io.IoError, ptr %sum.tmp10, i32 0, i32 1
  %vf = getelementptr inbounds nuw { i64 }, ptr %payload12, i32 0, i32 0
  store i64 0, ptr %vf, align 8
  %sum = load %io.IoError, ptr %sum.tmp10, align 8
  %vf13 = getelementptr inbounds nuw { %io.IoError }, ptr %payload, i32 0, i32 0
  store %io.IoError %sum, ptr %vf13, align 8
  %sum14 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  ret %coil.core.Result__i64__io.IoError %sum14

else9:                                            ; preds = %ifcont
  %tag16 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp15, i32 0, i32 0
  store i32 0, ptr %tag16, align 4
  %payload17 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp15, i32 0, i32 1
  %vf18 = getelementptr inbounds nuw { i64 }, ptr %payload17, i32 0, i32 0
  store i64 %ifval, ptr %vf18, align 8
  %sum19 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp15, align 8
  ret %coil.core.Result__i64__io.IoError %sum19
}

define internal %coil.core.Result__i64__io.IoError @io.fd-read(ptr %ctx, ptr %buf, i64 %len) {
entry:
  %sum.tmp6 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp1 = alloca %io.IoError, align 8
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %ptrtoint = ptrtoint ptr %ctx to i32
  %call = call i64 @read(i32 %ptrtoint, ptr %buf, i64 %len)
  %cmp = icmp slt i64 %call, 0
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 1, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %tag2 = getelementptr inbounds nuw %io.IoError, ptr %sum.tmp1, i32 0, i32 0
  store i32 1, ptr %tag2, align 4
  %payload3 = getelementptr inbounds nuw %io.IoError, ptr %sum.tmp1, i32 0, i32 1
  %vf = getelementptr inbounds nuw { i64 }, ptr %payload3, i32 0, i32 0
  store i64 %call, ptr %vf, align 8
  %sum = load %io.IoError, ptr %sum.tmp1, align 8
  %vf4 = getelementptr inbounds nuw { %io.IoError }, ptr %payload, i32 0, i32 0
  store %io.IoError %sum, ptr %vf4, align 8
  %sum5 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  ret %coil.core.Result__i64__io.IoError %sum5

else:                                             ; preds = %entry
  %tag7 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, i32 0, i32 0
  store i32 0, ptr %tag7, align 4
  %payload8 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, i32 0, i32 1
  %vf9 = getelementptr inbounds nuw { i64 }, ptr %payload8, i32 0, i32 0
  store i64 %call, ptr %vf9, align 8
  %sum10 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, align 8
  ret %coil.core.Result__i64__io.IoError %sum10
}

define internal ptr @io.fd-reader(ptr %r, i64 %fd) {
entry:
  %field = getelementptr inbounds nuw %io.Reader, ptr %r, i32 0, i32 0
  store ptr @io.fd-read, ptr %field, align 8
  %field1 = getelementptr inbounds nuw %io.Reader, ptr %r, i32 0, i32 1
  %inttoptr = inttoptr i64 %fd to ptr
  store ptr %inttoptr, ptr %field1, align 8
  ret ptr %r
}

define internal %coil.core.Result__i64__io.IoError @io.fd-write(ptr %ctx, ptr %buf, i64 %len) {
entry:
  %sum.tmp6 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp1 = alloca %io.IoError, align 8
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %ptrtoint = ptrtoint ptr %ctx to i32
  %call = call i64 @write(i32 %ptrtoint, ptr %buf, i64 %len)
  %cmp = icmp slt i64 %call, 0
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 1, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %tag2 = getelementptr inbounds nuw %io.IoError, ptr %sum.tmp1, i32 0, i32 0
  store i32 1, ptr %tag2, align 4
  %payload3 = getelementptr inbounds nuw %io.IoError, ptr %sum.tmp1, i32 0, i32 1
  %vf = getelementptr inbounds nuw { i64 }, ptr %payload3, i32 0, i32 0
  store i64 %call, ptr %vf, align 8
  %sum = load %io.IoError, ptr %sum.tmp1, align 8
  %vf4 = getelementptr inbounds nuw { %io.IoError }, ptr %payload, i32 0, i32 0
  store %io.IoError %sum, ptr %vf4, align 8
  %sum5 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  ret %coil.core.Result__i64__io.IoError %sum5

else:                                             ; preds = %entry
  %tag7 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, i32 0, i32 0
  store i32 0, ptr %tag7, align 4
  %payload8 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, i32 0, i32 1
  %vf9 = getelementptr inbounds nuw { i64 }, ptr %payload8, i32 0, i32 0
  store i64 %call, ptr %vf9, align 8
  %sum10 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, align 8
  ret %coil.core.Result__i64__io.IoError %sum10
}

define internal ptr @io.fd-writer(ptr %w, i64 %fd) {
entry:
  %field = getelementptr inbounds nuw %io.Writer, ptr %w, i32 0, i32 0
  store ptr @io.fd-write, ptr %field, align 8
  %field1 = getelementptr inbounds nuw %io.Writer, ptr %w, i32 0, i32 1
  %inttoptr = inttoptr i64 %fd to ptr
  store ptr %inttoptr, ptr %field1, align 8
  ret ptr %w
}

define internal ptr @io.fixed-buffer-writer(ptr %w, ptr %fb) {
entry:
  %field = getelementptr inbounds nuw %io.FixBuf, ptr %fb, i32 0, i32 1
  store i64 0, ptr %field, align 8
  %field1 = getelementptr inbounds nuw %io.Writer, ptr %w, i32 0, i32 0
  store ptr @io.fb-write, ptr %field1, align 8
  %field2 = getelementptr inbounds nuw %io.Writer, ptr %w, i32 0, i32 1
  store ptr %fb, ptr %field2, align 8
  ret ptr %w
}

define internal %coil.core.Result__i64__io.IoError @io.null-write(ptr %ctx, ptr %buf, i64 %len) {
entry:
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 0, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %vf = getelementptr inbounds nuw { i64 }, ptr %payload, i32 0, i32 0
  store i64 %len, ptr %vf, align 8
  %sum = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  ret %coil.core.Result__i64__io.IoError %sum
}

define internal ptr @io.null-writer() {
entry:
  store ptr @io.null-write, ptr @g.1, align 8
  store ptr null, ptr getelementptr inbounds nuw (%io.Writer, ptr @g.1, i32 0, i32 1), align 8
  ret ptr @g.1
}

define internal %coil.core.Result__i64__io.IoError @io.print-cstr(ptr %w, ptr %s) {
entry:
  %call = call i64 @strlen(ptr %s)
  %call1 = call %coil.core.Result__i64__io.IoError @io.write-all(ptr %w, ptr %s, i64 %call)
  ret %coil.core.Result__i64__io.IoError %call1
}

define internal %coil.core.Result__i64__io.IoError @io.print-int(ptr %w, i64 %n) {
entry:
  %cmp = icmp slt i64 %n, 10
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %add = add i64 %n, 48
  %trunc = trunc i64 %add to i8
  %call = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 %trunc)
  ret %coil.core.Result__i64__io.IoError %call

else:                                             ; preds = %entry
  %div = sdiv i64 %n, 10
  %call1 = call %coil.core.Result__i64__io.IoError @io.print-int(ptr %w, i64 %div)
  %rem = srem i64 %n, 10
  %add2 = add i64 %rem, 48
  %trunc3 = trunc i64 %add2 to i8
  %call4 = call %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 %trunc3)
  ret %coil.core.Result__i64__io.IoError %call4
}

define internal %coil.core.Result__i64__io.IoError @io.print-str(ptr %w, { ptr, i64 } %s) {
entry:
  %call = call ptr @slice.slice-data__u8({ ptr, i64 } %s)
  %call1 = call i64 @slice.slice-len__u8({ ptr, i64 } %s)
  %call2 = call %coil.core.Result__i64__io.IoError @io.write-all(ptr %w, ptr %call, i64 %call1)
  ret %coil.core.Result__i64__io.IoError %call2
}

define internal %coil.core.Result__i64__io.IoError @io.read-exact(ptr %r, ptr %buf, i64 %len) {
entry:
  %sum.tmp15 = alloca %io.IoError, align 8
  %sum.tmp12 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp7 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %match.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %call = call %coil.core.Result__i64__io.IoError @io.read-fill(ptr %r, ptr %buf, i64 %len)
  store %coil.core.Result__i64__io.IoError %call, ptr %match.tmp, align 8
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 0
  %tag1 = load i32, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 1
  switch i32 %tag1, label %match.default [
    i32 1, label %arm
    i32 0, label %arm2
  ]

arm:                                              ; preds = %entry
  %vf = getelementptr inbounds nuw { %io.IoError }, ptr %payload, i32 0, i32 0
  %e = load %io.IoError, ptr %vf, align 8
  %tag3 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 1, ptr %tag3, align 4
  %payload4 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %vf5 = getelementptr inbounds nuw { %io.IoError }, ptr %payload4, i32 0, i32 0
  store %io.IoError %e, ptr %vf5, align 8
  %sum = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  ret %coil.core.Result__i64__io.IoError %sum

arm2:                                             ; preds = %entry
  %vf6 = getelementptr inbounds nuw { i64 }, ptr %payload, i32 0, i32 0
  %n = load i64, ptr %vf6, align 8
  %cmp = icmp eq i64 %n, %len
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

match.default:                                    ; preds = %entry
  unreachable

then:                                             ; preds = %arm2
  %tag8 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp7, i32 0, i32 0
  store i32 0, ptr %tag8, align 4
  %payload9 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp7, i32 0, i32 1
  %vf10 = getelementptr inbounds nuw { i64 }, ptr %payload9, i32 0, i32 0
  store i64 %n, ptr %vf10, align 8
  %sum11 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp7, align 8
  ret %coil.core.Result__i64__io.IoError %sum11

else:                                             ; preds = %arm2
  %tag13 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp12, i32 0, i32 0
  store i32 1, ptr %tag13, align 4
  %payload14 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp12, i32 0, i32 1
  %tag16 = getelementptr inbounds nuw %io.IoError, ptr %sum.tmp15, i32 0, i32 0
  store i32 0, ptr %tag16, align 4
  %payload17 = getelementptr inbounds nuw %io.IoError, ptr %sum.tmp15, i32 0, i32 1
  %sum18 = load %io.IoError, ptr %sum.tmp15, align 8
  %vf19 = getelementptr inbounds nuw { %io.IoError }, ptr %payload14, i32 0, i32 0
  store %io.IoError %sum18, ptr %vf19, align 8
  %sum20 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp12, align 8
  ret %coil.core.Result__i64__io.IoError %sum20
}

define internal %coil.core.Result__i64__io.IoError @io.read-fill(ptr %r, ptr %buf, i64 %len) {
entry:
  %sum.tmp37 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp31 = alloca %coil.core.Result__i64__io.IoError, align 8
  %match.tmp22 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp16 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp6 = alloca %coil.core.Result__i64__io.IoError, align 8
  %match.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %cmp = icmp sle i64 %len, 0
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 0, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %vf = getelementptr inbounds nuw { i64 }, ptr %payload, i32 0, i32 0
  store i64 0, ptr %vf, align 8
  %sum = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  ret %coil.core.Result__i64__io.IoError %sum

else:                                             ; preds = %entry
  %call = call %coil.core.Result__i64__io.IoError @io.read-some(ptr %r, ptr %buf, i64 %len)
  store %coil.core.Result__i64__io.IoError %call, ptr %match.tmp, align 8
  %tag1 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 0
  %tag2 = load i32, ptr %tag1, align 4
  %payload3 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 1
  switch i32 %tag2, label %match.default [
    i32 1, label %arm
    i32 0, label %arm4
  ]

arm:                                              ; preds = %else
  %vf5 = getelementptr inbounds nuw { %io.IoError }, ptr %payload3, i32 0, i32 0
  %e = load %io.IoError, ptr %vf5, align 8
  %tag7 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, i32 0, i32 0
  store i32 1, ptr %tag7, align 4
  %payload8 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, i32 0, i32 1
  %vf9 = getelementptr inbounds nuw { %io.IoError }, ptr %payload8, i32 0, i32 0
  store %io.IoError %e, ptr %vf9, align 8
  %sum10 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, align 8
  ret %coil.core.Result__i64__io.IoError %sum10

arm4:                                             ; preds = %else
  %vf11 = getelementptr inbounds nuw { i64 }, ptr %payload3, i32 0, i32 0
  %n = load i64, ptr %vf11, align 8
  %cmp12 = icmp sle i64 %n, 0
  %ifc13 = icmp ne i1 %cmp12, false
  br i1 %ifc13, label %then14, label %else15

match.default:                                    ; preds = %else
  unreachable

then14:                                           ; preds = %arm4
  %tag17 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp16, i32 0, i32 0
  store i32 0, ptr %tag17, align 4
  %payload18 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp16, i32 0, i32 1
  %vf19 = getelementptr inbounds nuw { i64 }, ptr %payload18, i32 0, i32 0
  store i64 0, ptr %vf19, align 8
  %sum20 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp16, align 8
  ret %coil.core.Result__i64__io.IoError %sum20

else15:                                           ; preds = %arm4
  %idx = getelementptr i8, ptr %buf, i64 %n
  %sub = sub i64 %len, %n
  %call21 = call %coil.core.Result__i64__io.IoError @io.read-fill(ptr %r, ptr %idx, i64 %sub)
  store %coil.core.Result__i64__io.IoError %call21, ptr %match.tmp22, align 8
  %tag23 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp22, i32 0, i32 0
  %tag24 = load i32, ptr %tag23, align 4
  %payload25 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp22, i32 0, i32 1
  switch i32 %tag24, label %match.default28 [
    i32 1, label %arm26
    i32 0, label %arm27
  ]

arm26:                                            ; preds = %else15
  %vf29 = getelementptr inbounds nuw { %io.IoError }, ptr %payload25, i32 0, i32 0
  %e30 = load %io.IoError, ptr %vf29, align 8
  %tag32 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp31, i32 0, i32 0
  store i32 1, ptr %tag32, align 4
  %payload33 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp31, i32 0, i32 1
  %vf34 = getelementptr inbounds nuw { %io.IoError }, ptr %payload33, i32 0, i32 0
  store %io.IoError %e30, ptr %vf34, align 8
  %sum35 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp31, align 8
  ret %coil.core.Result__i64__io.IoError %sum35

arm27:                                            ; preds = %else15
  %vf36 = getelementptr inbounds nuw { i64 }, ptr %payload25, i32 0, i32 0
  %m = load i64, ptr %vf36, align 8
  %tag38 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp37, i32 0, i32 0
  store i32 0, ptr %tag38, align 4
  %payload39 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp37, i32 0, i32 1
  %add = add i64 %n, %m
  %vf40 = getelementptr inbounds nuw { i64 }, ptr %payload39, i32 0, i32 0
  store i64 %add, ptr %vf40, align 8
  %sum41 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp37, align 8
  ret %coil.core.Result__i64__io.IoError %sum41

match.default28:                                  ; preds = %else15
  unreachable
}

define internal %coil.core.Result__i64__io.IoError @io.read-line(ptr %r, ptr %buf, i64 %cap) {
entry:
  %sum.tmp45 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp34 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp28 = alloca %io.IoError, align 8
  %sum.tmp25 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp10 = alloca %coil.core.Result__i64__io.IoError, align 8
  %match.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %stack.slot = alloca i64, align 8
  store i64 0, ptr %stack.slot, align 8
  %stack.slot1 = alloca i8, align 1
  br label %loop.body

loop.body:                                        ; preds = %entry
  br label %loop.body2

loop.after:                                       ; preds = %then43, %ifcont, %arm, %then
  %loop.val = phi %coil.core.Result__i64__io.IoError [ %sum, %then ], [ %sum14, %arm ], [ %ifval, %ifcont ], [ %sum50, %then43 ]
  ret %coil.core.Result__i64__io.IoError %loop.val

loop.body2:                                       ; preds = %match.end, %loop.body
  %load = load i64, ptr %stack.slot, align 8
  %cmp = icmp sge i64 %load, %cap
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

loop.after3:                                      ; No predecessors!
  unreachable

then:                                             ; preds = %loop.body2
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 0, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %load4 = load i64, ptr %stack.slot, align 8
  %vf = getelementptr inbounds nuw { i64 }, ptr %payload, i32 0, i32 0
  store i64 %load4, ptr %vf, align 8
  %sum = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  br label %loop.after

else:                                             ; preds = %loop.body2
  %call = call %coil.core.Result__i64__io.IoError @io.read-some(ptr %r, ptr %stack.slot1, i64 1)
  store %coil.core.Result__i64__io.IoError %call, ptr %match.tmp, align 8
  %tag5 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 0
  %tag6 = load i32, ptr %tag5, align 4
  %payload7 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 1
  switch i32 %tag6, label %match.default [
    i32 1, label %arm
    i32 0, label %arm8
  ]

arm:                                              ; preds = %else
  %vf9 = getelementptr inbounds nuw { %io.IoError }, ptr %payload7, i32 0, i32 0
  %e = load %io.IoError, ptr %vf9, align 8
  %tag11 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp10, i32 0, i32 0
  store i32 1, ptr %tag11, align 4
  %payload12 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp10, i32 0, i32 1
  %vf13 = getelementptr inbounds nuw { %io.IoError }, ptr %payload12, i32 0, i32 0
  store %io.IoError %e, ptr %vf13, align 8
  %sum14 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp10, align 8
  br label %loop.after

arm8:                                             ; preds = %else
  %vf15 = getelementptr inbounds nuw { i64 }, ptr %payload7, i32 0, i32 0
  %n = load i64, ptr %vf15, align 8
  %cmp16 = icmp sle i64 %n, 0
  %ifc17 = icmp ne i1 %cmp16, false
  br i1 %ifc17, label %then18, label %else19

match.default:                                    ; preds = %else
  unreachable

match.end:                                        ; preds = %else44
  %match.val = phi i64 [ 0, %else44 ]
  br label %loop.body2

then18:                                           ; preds = %arm8
  %load20 = load i64, ptr %stack.slot, align 8
  %cmp21 = icmp eq i64 %load20, 0
  %ifc22 = icmp ne i1 %cmp21, false
  br i1 %ifc22, label %then23, label %else24

else19:                                           ; preds = %arm8
  %load40 = load i8, ptr %stack.slot1, align 1
  %zext = zext i8 %load40 to i64
  %cmp41 = icmp eq i64 %zext, 10
  %ifc42 = icmp ne i1 %cmp41, false
  br i1 %ifc42, label %then43, label %else44

then23:                                           ; preds = %then18
  %tag26 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp25, i32 0, i32 0
  store i32 1, ptr %tag26, align 4
  %payload27 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp25, i32 0, i32 1
  %tag29 = getelementptr inbounds nuw %io.IoError, ptr %sum.tmp28, i32 0, i32 0
  store i32 0, ptr %tag29, align 4
  %payload30 = getelementptr inbounds nuw %io.IoError, ptr %sum.tmp28, i32 0, i32 1
  %sum31 = load %io.IoError, ptr %sum.tmp28, align 8
  %vf32 = getelementptr inbounds nuw { %io.IoError }, ptr %payload27, i32 0, i32 0
  store %io.IoError %sum31, ptr %vf32, align 8
  %sum33 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp25, align 8
  br label %ifcont

else24:                                           ; preds = %then18
  %tag35 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp34, i32 0, i32 0
  store i32 0, ptr %tag35, align 4
  %payload36 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp34, i32 0, i32 1
  %load37 = load i64, ptr %stack.slot, align 8
  %vf38 = getelementptr inbounds nuw { i64 }, ptr %payload36, i32 0, i32 0
  store i64 %load37, ptr %vf38, align 8
  %sum39 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp34, align 8
  br label %ifcont

ifcont:                                           ; preds = %else24, %then23
  %ifval = phi %coil.core.Result__i64__io.IoError [ %sum33, %then23 ], [ %sum39, %else24 ]
  br label %loop.after

then43:                                           ; preds = %else19
  %tag46 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp45, i32 0, i32 0
  store i32 0, ptr %tag46, align 4
  %payload47 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp45, i32 0, i32 1
  %load48 = load i64, ptr %stack.slot, align 8
  %vf49 = getelementptr inbounds nuw { i64 }, ptr %payload47, i32 0, i32 0
  store i64 %load48, ptr %vf49, align 8
  %sum50 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp45, align 8
  br label %loop.after

else44:                                           ; preds = %else19
  %load51 = load i64, ptr %stack.slot, align 8
  %idx = getelementptr i8, ptr %buf, i64 %load51
  store i8 %load40, ptr %idx, align 1
  %load52 = load i64, ptr %stack.slot, align 8
  %add = add i64 %load52, 1
  store i64 %add, ptr %stack.slot, align 8
  br label %match.end
}

define internal %coil.core.Result__i64__io.IoError @io.read-some(ptr %r, ptr %buf, i64 %len) {
entry:
  %field = getelementptr inbounds nuw %io.Reader, ptr %r, i32 0, i32 0
  %load = load ptr, ptr %field, align 8
  %field1 = getelementptr inbounds nuw %io.Reader, ptr %r, i32 0, i32 1
  %load2 = load ptr, ptr %field1, align 8
  %callptr = call %coil.core.Result__i64__io.IoError %load(ptr %load2, ptr %buf, i64 %len)
  ret %coil.core.Result__i64__io.IoError %callptr
}

define internal ptr @io.stderr() {
entry:
  %call = call ptr @io.fd-writer(ptr @g.2, i64 2)
  ret ptr %call
}

define internal ptr @io.stdin() {
entry:
  %call = call ptr @io.fd-reader(ptr @g.3, i64 0)
  ret ptr %call
}

define internal ptr @io.stdout() {
entry:
  %call = call ptr @io.fd-writer(ptr @g.4, i64 1)
  ret ptr %call
}

define internal %coil.core.Result__i64__io.IoError @io.write-all(ptr %w, ptr %buf, i64 %len) {
entry:
  %sum.tmp42 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp36 = alloca %coil.core.Result__i64__io.IoError, align 8
  %match.tmp27 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp19 = alloca %io.IoError, align 8
  %sum.tmp16 = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp6 = alloca %coil.core.Result__i64__io.IoError, align 8
  %match.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %sum.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %cmp = icmp sle i64 %len, 0
  %ifc = icmp ne i1 %cmp, false
  br i1 %ifc, label %then, label %else

then:                                             ; preds = %entry
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 0
  store i32 0, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp, i32 0, i32 1
  %vf = getelementptr inbounds nuw { i64 }, ptr %payload, i32 0, i32 0
  store i64 0, ptr %vf, align 8
  %sum = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp, align 8
  ret %coil.core.Result__i64__io.IoError %sum

else:                                             ; preds = %entry
  %call = call %coil.core.Result__i64__io.IoError @io.write-some(ptr %w, ptr %buf, i64 %len)
  store %coil.core.Result__i64__io.IoError %call, ptr %match.tmp, align 8
  %tag1 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 0
  %tag2 = load i32, ptr %tag1, align 4
  %payload3 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 1
  switch i32 %tag2, label %match.default [
    i32 1, label %arm
    i32 0, label %arm4
  ]

arm:                                              ; preds = %else
  %vf5 = getelementptr inbounds nuw { %io.IoError }, ptr %payload3, i32 0, i32 0
  %e = load %io.IoError, ptr %vf5, align 8
  %tag7 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, i32 0, i32 0
  store i32 1, ptr %tag7, align 4
  %payload8 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, i32 0, i32 1
  %vf9 = getelementptr inbounds nuw { %io.IoError }, ptr %payload8, i32 0, i32 0
  store %io.IoError %e, ptr %vf9, align 8
  %sum10 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp6, align 8
  ret %coil.core.Result__i64__io.IoError %sum10

arm4:                                             ; preds = %else
  %vf11 = getelementptr inbounds nuw { i64 }, ptr %payload3, i32 0, i32 0
  %n = load i64, ptr %vf11, align 8
  %cmp12 = icmp sle i64 %n, 0
  %ifc13 = icmp ne i1 %cmp12, false
  br i1 %ifc13, label %then14, label %else15

match.default:                                    ; preds = %else
  unreachable

then14:                                           ; preds = %arm4
  %tag17 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp16, i32 0, i32 0
  store i32 1, ptr %tag17, align 4
  %payload18 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp16, i32 0, i32 1
  %tag20 = getelementptr inbounds nuw %io.IoError, ptr %sum.tmp19, i32 0, i32 0
  store i32 1, ptr %tag20, align 4
  %payload21 = getelementptr inbounds nuw %io.IoError, ptr %sum.tmp19, i32 0, i32 1
  %vf22 = getelementptr inbounds nuw { i64 }, ptr %payload21, i32 0, i32 0
  store i64 0, ptr %vf22, align 8
  %sum23 = load %io.IoError, ptr %sum.tmp19, align 8
  %vf24 = getelementptr inbounds nuw { %io.IoError }, ptr %payload18, i32 0, i32 0
  store %io.IoError %sum23, ptr %vf24, align 8
  %sum25 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp16, align 8
  ret %coil.core.Result__i64__io.IoError %sum25

else15:                                           ; preds = %arm4
  %idx = getelementptr i8, ptr %buf, i64 %n
  %sub = sub i64 %len, %n
  %call26 = call %coil.core.Result__i64__io.IoError @io.write-all(ptr %w, ptr %idx, i64 %sub)
  store %coil.core.Result__i64__io.IoError %call26, ptr %match.tmp27, align 8
  %tag28 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp27, i32 0, i32 0
  %tag29 = load i32, ptr %tag28, align 4
  %payload30 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp27, i32 0, i32 1
  switch i32 %tag29, label %match.default33 [
    i32 1, label %arm31
    i32 0, label %arm32
  ]

arm31:                                            ; preds = %else15
  %vf34 = getelementptr inbounds nuw { %io.IoError }, ptr %payload30, i32 0, i32 0
  %e35 = load %io.IoError, ptr %vf34, align 8
  %tag37 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp36, i32 0, i32 0
  store i32 1, ptr %tag37, align 4
  %payload38 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp36, i32 0, i32 1
  %vf39 = getelementptr inbounds nuw { %io.IoError }, ptr %payload38, i32 0, i32 0
  store %io.IoError %e35, ptr %vf39, align 8
  %sum40 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp36, align 8
  ret %coil.core.Result__i64__io.IoError %sum40

arm32:                                            ; preds = %else15
  %vf41 = getelementptr inbounds nuw { i64 }, ptr %payload30, i32 0, i32 0
  %m = load i64, ptr %vf41, align 8
  %tag43 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp42, i32 0, i32 0
  store i32 0, ptr %tag43, align 4
  %payload44 = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %sum.tmp42, i32 0, i32 1
  %add = add i64 %n, %m
  %vf45 = getelementptr inbounds nuw { i64 }, ptr %payload44, i32 0, i32 0
  store i64 %add, ptr %vf45, align 8
  %sum46 = load %coil.core.Result__i64__io.IoError, ptr %sum.tmp42, align 8
  ret %coil.core.Result__i64__io.IoError %sum46

match.default33:                                  ; preds = %else15
  unreachable
}

define internal %coil.core.Result__i64__io.IoError @io.write-byte(ptr %w, i8 %b) {
entry:
  %stack.slot = alloca i8, align 1
  store i8 %b, ptr %stack.slot, align 1
  %call = call %coil.core.Result__i64__io.IoError @io.write-all(ptr %w, ptr %stack.slot, i64 1)
  ret %coil.core.Result__i64__io.IoError %call
}

define internal %coil.core.Result__i64__io.IoError @io.write-some(ptr %w, ptr %buf, i64 %len) {
entry:
  %field = getelementptr inbounds nuw %io.Writer, ptr %w, i32 0, i32 0
  %load = load ptr, ptr %field, align 8
  %field1 = getelementptr inbounds nuw %io.Writer, ptr %w, i32 0, i32 1
  %load2 = load ptr, ptr %field1, align 8
  %callptr = call %coil.core.Result__i64__io.IoError %load(ptr %load2, ptr %buf, i64 %len)
  ret %coil.core.Result__i64__io.IoError %callptr
}

define i64 @main() {
entry:
  %match.tmp = alloca %coil.core.Result__i64__io.IoError, align 8
  %spill = alloca %coil.core.Option__ptr_i8, align 8
  %call = call ptr @alloc.malloc-allocator()
  %call1 = call %coil.core.Option__ptr_i8 @alloc.alloc-slice__i8(ptr %call, i64 64)
  store %coil.core.Option__ptr_i8 %call1, ptr %spill, align 8
  %call2 = call ptr @alloc.unwrap-ptr__i8(ptr %spill)
  store ptr %call2, ptr @g.5, align 8
  store i64 64, ptr getelementptr inbounds nuw (%io.FixBuf, ptr @g.5, i32 0, i32 2), align 8
  %stack.slot = alloca %io.Writer, align 8
  %call3 = call ptr @io.fixed-buffer-writer(ptr %stack.slot, ptr @g.5)
  %call4 = call %coil.core.Result__i64__io.IoError @app.greet(ptr %call3, i64 42)
  %call5 = call ptr @io.stdout()
  %load = load ptr, ptr @g.5, align 8
  %load6 = load i64, ptr getelementptr inbounds nuw (%io.FixBuf, ptr @g.5, i32 0, i32 1), align 8
  %call7 = call %coil.core.Result__i64__io.IoError @io.write-all(ptr %call5, ptr %load, i64 %load6)
  store %coil.core.Result__i64__io.IoError %call7, ptr %match.tmp, align 8
  %tag = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 0
  %tag8 = load i32, ptr %tag, align 4
  %payload = getelementptr inbounds nuw %coil.core.Result__i64__io.IoError, ptr %match.tmp, i32 0, i32 1
  switch i32 %tag8, label %match.default [
    i32 0, label %arm
    i32 1, label %arm9
  ]

arm:                                              ; preds = %entry
  %vf = getelementptr inbounds nuw { i64 }, ptr %payload, i32 0, i32 0
  %n = load i64, ptr %vf, align 8
  ret i64 0

arm9:                                             ; preds = %entry
  %vf10 = getelementptr inbounds nuw { %io.IoError }, ptr %payload, i32 0, i32 0
  %e = load %io.IoError, ptr %vf10, align 8
  ret i64 1

match.default:                                    ; preds = %entry
  unreachable
}

define internal ptr @slice.slice-data__u8({ ptr, i64 } %s) {
entry:
  %llvmir = call ptr @__coil_llvm_ir_0({ ptr, i64 } %s)
  ret ptr %llvmir
}

define internal i64 @slice.slice-len__u8({ ptr, i64 } %s) {
entry:
  %llvmir = call i64 @__coil_llvm_ir_1({ ptr, i64 } %s)
  ret i64 %llvmir
}

; Function Attrs: alwaysinline

; Function Attrs: alwaysinline

attributes #0 = { alwaysinline }

