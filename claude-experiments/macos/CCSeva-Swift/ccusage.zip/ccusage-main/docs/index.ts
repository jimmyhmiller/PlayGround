export default {
	fetch() {
		return new Response('ccusage');
	},
};
